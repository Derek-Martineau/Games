
module GuessingGame {
	requires java.desktop;
}
package GuessingGame;

public class GuessingApplication {

	public static void main(String[] args) {

		// create the entry form and show it
		GuessEntryForm form = new GuessEntryForm();
		form.show();
	}

}

#Pyhtin credit validator program

#1. Remove any '-' or ' '
#2. add all digits in the odd places from right to left
#3. Double every second digit from right to left
#      (if results is a two-digit number,
#      add the two-digit number together ro fet a single digit.)
#4. Sum the totals of sets 2 & 3
#5. If sum is devisible by 10, the credit card # is valid

#Declare variables
sum_odd_digits = 0
sum_even_digits = 0
total = 0

#step 1.
#user enters card number
card_number = input("enter a credit card #: ")
#removes any - and spaces
card_number = card_number.replace("-", "")
card_number = card_number.replace(" ", "")
#reverse string
card_number = card_number[::-1]
#print(card_number)

#step 2.
for x in card_number[::2]:
    sum_odd_digits += int(x)

#step 3.
for x in card_number[1::2]:
    x = int(x) * 2
    if x>= 10:
        sum_even_digits += (1 + (x % 10))
    else:
        sum_even_digits += x

#step 4
total = sum_odd_digits + sum_even_digits

#step 5
if total % 10 == 0:
    print("VALID")
else:
    print("INVALID")


